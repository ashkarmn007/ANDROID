package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    Button button0, button1, button2, button3, button4, button5, button6, button7, button8, button9;
    Button buttonDot, buttonAdd, buttonSub, buttonMul, buttonDiv, buttonC, buttonEql;
    EditText result;

    float mValueOne, mValueTwo;
    boolean add, sub, mul, div;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize buttons
        button0 = findViewById(R.id.button0);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);

        buttonDot = findViewById(R.id.buttondot);
        buttonAdd = findViewById(R.id.buttonadd);
        buttonSub = findViewById(R.id.buttonsub);
        buttonMul = findViewById(R.id.buttonmul);
        buttonDiv = findViewById(R.id.buttondiv);
        buttonC = findViewById(R.id.buttonC);
        buttonEql = findViewById(R.id.buttoneql);

        result = findViewById(R.id.ed
        );

        // Number buttons
        View.OnClickListener numberListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button b = (Button) v;
                result.setText(result.getText().toString() + b.getText().toString());
            }
        };

        button0.setOnClickListener(numberListener);
        button1.setOnClickListener(numberListener);
        button2.setOnClickListener(numberListener);
        button3.setOnClickListener(numberListener);
        button4.setOnClickListener(numberListener);
        button5.setOnClickListener(numberListener);
        button6.setOnClickListener(numberListener);
        button7.setOnClickListener(numberListener);
        button8.setOnClickListener(numberListener);
        button9.setOnClickListener(numberListener);
        buttonDot.setOnClickListener(numberListener);

        // Clear button
        buttonC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result.setText("");
                mValueOne = mValueTwo = 0;
                add = sub = mul = div = false;
            }
        });

        // Operation buttons
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!result.getText().toString().equals("")) {
                    mValueOne = Float.parseFloat(result.getText().toString());
                    add = true;
                    result.setText(null);
                }
            }
        });

        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!result.getText().toString().equals("")) {
                    mValueOne = Float.parseFloat(result.getText().toString());
                    sub = true;
                    result.setText(null);
                }
            }
        });

        buttonMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!result.getText().toString().equals("")) {
                    mValueOne = Float.parseFloat(result.getText().toString());
                    mul = true;
                    result.setText(null);
                }
            }
        });

        buttonDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!result.getText().toString().equals("")) {
                    mValueOne = Float.parseFloat(result.getText().toString());
                    div = true;
                    result.setText(null);
                }
            }
        });

        // Equal button
        buttonEql.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!result.getText().toString().equals("")) {
                    mValueTwo = Float.parseFloat(result.getText().toString());

                    if (add) {
                        result.setText(String.valueOf(mValueOne + mValueTwo));
                        add = false;
                    } else if (sub) {
                        result.setText(String.valueOf(mValueOne - mValueTwo));
                        sub = false;
                    } else if (mul) {
                        result.setText(String.valueOf(mValueOne * mValueTwo));
                        mul = false;
                    } else if (div) {
                        if (mValueTwo == 0) {
                            result.setText("Error");
                        } else {
                            result.setText(String.valueOf(mValueOne / mValueTwo));
                        }
                        div = false;
                    }
                }
            }
        });
    }
}
